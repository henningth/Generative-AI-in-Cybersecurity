"""
Demo code for tool calling, module 4, 
for the course Generative AI in Cybersecurity at UCN.

Author: Henning Thomsen
"""

from langchain.agents import initialize_agent, AgentType
from langchain_openai import ChatOpenAI
from langchain_groq import ChatGroq

from dotenv import load_dotenv
load_dotenv()

tools = """
- `ip_lookup`: Look up threat intelligence information about an IP address.
  Example: {"tool": "ip_lookup", "args": {"ip": "192.0.2.123"}}

- `domain_reputation`: Get reputation score and history of a domain.
  Example: {"tool": "domain_reputation", "args": {"domain": "suspicious-domain.com"}}

- `whois_lookup`: Retrieve WHOIS registration details for a domain.
  Example: {"tool": "whois_lookup", "args": {"domain": "suspicious-domain.com"}}
"""

question = "We received an alert about outbound traffic to 192.0.2.123. Can you investigate this IP?"

prompt = f"""
You are an expert in cybersecurity, and your job is to answer questions from a SOC analyst.

You have access to these tools: {tools}

When the analyst asks a question, you should first reflect with your thoughts, in this format: 'Thoughts: {{thoughts}}'

Then your should either:

- Call a tool with JSON formatting (tool-name and arguments)
- Print the answer, starting with: Answer:

Indiciate which of the two options you use.

Analyst question: {question}
"""

# Run OpenAI model
OPENAI_MODEL = "gpt-4o-mini"
print(f"\nUsing OpenAI model {OPENAI_MODEL}:\n")
llm = ChatOpenAI(model=OPENAI_MODEL, temperature=0.1)
response = llm.invoke(prompt)
print(response.content)

# Run model via Groq
GROQ_MODEL = "llama3-8b-8192"
print(f"\nUsing open-source model {GROQ_MODEL}:\n")
llm = ChatGroq(model=GROQ_MODEL, temperature=0.1)
response = llm.invoke(prompt)
print(response.content)
"""
Demo code for tool calling, module 4, 
for the course Generative AI in Cybersecurity at UCN.

Author: Henning Thomsen
"""

from langchain.agents import initialize_agent, AgentType
from langchain_openai import ChatOpenAI
from langchain_groq import ChatGroq

from dotenv import load_dotenv
load_dotenv()

"""
Defines tools, note that these are defined as standard Python functions
"""
def ip_lookup(ip: str) -> str:
    mock_response = {
        "192.0.2.123": {
            "threat_level": "high",
            "reason": "Known to be part of a botnet (Mirai variant)",
            "geo": "Russia",
            "last_seen": "2024-12-01"
        }
    }
    result = mock_response.get(ip, {"threat_level": "unknown", "reason": "IP not found in threat database"})
    return f"Threat Level: {result['threat_level']}\nReason: {result['reason']}\nGeo: {result.get('geo', 'N/A')}\nLast Seen: {result.get('last_seen', 'N/A')}"


tools = """
- `ip_lookup`: Look up threat intelligence information about an IP address.
  Example: {"tool": "ip_lookup", "args": {"ip": "192.0.2.123"}}

- `domain_reputation`: Get reputation score and history of a domain.
  Example: {"tool": "domain_reputation", "args": {"domain": "suspicious-domain.com"}}

- `whois_lookup`: Retrieve WHOIS registration details for a domain.
  Example: {"tool": "whois_lookup", "args": {"domain": "suspicious-domain.com"}}
"""

question = "We received an alert about outbound traffic to 192.0.2.123. Can you investigate this IP?"

prompt = f"""
You are an expert in cybersecurity, and your job is to answer questions from a SOC analyst.

You have access to these tools: {tools}

When the analyst asks a question, you should first reflect with your thoughts, in this format: 'Thoughts: {{thoughts}}'

Then your should either:

- Call a tool with JSON formatting (tool-name and arguments)
- Print the answer, starting with: Answer:

Indiciate which of the two options you use.

Analyst question: {question}
"""

# Run OpenAI model
OPENAI_MODEL = "gpt-4o-mini"
print(f"\nUsing OpenAI model {OPENAI_MODEL}:\n")
llm = ChatOpenAI(model=OPENAI_MODEL, temperature=0.1)
response = llm.invoke(prompt)
print(response.content)
"""
# Run model via Groq
GROQ_MODEL = "llama3-8b-8192"
print(f"\nUsing open-source model {GROQ_MODEL}:\n")
llm = ChatGroq(model=GROQ_MODEL, temperature=0.1)
response = llm.invoke(prompt)
print(response.content)
"""
import json

# Parse tool call
tool_call_line = next((line for line in response.content.splitlines() if line.strip().startswith('{')), None)
if tool_call_line:
    tool_call = json.loads(tool_call_line)
    tool_name = tool_call.get("tool")
    args = tool_call.get("args", {})

    if tool_name == "ip_lookup":
        tool_output = ip_lookup(**args)
        print("\nTool Output:\n", tool_output)

# Send result back to LLM for interpretation
followup_prompt = f"""
You previously asked to use the `ip_lookup` tool on {args['ip']}. The tool returned:

{tool_output}

Please interpret this result and provide recommendations, starting with: Answer:
"""

final_response = llm.invoke(followup_prompt)
print("\nFinal LLM Answer:\n", final_response.content)

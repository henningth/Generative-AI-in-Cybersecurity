"""
Demo code for plan and execute prompting, module 4, 
for the course Generative AI in Cybersecurity at UCN.

Author: Henning Thomsen
"""

from langchain.agents import initialize_agent, AgentType
from langchain_openai import ChatOpenAI
from langchain_groq import ChatGroq

from dotenv import load_dotenv
load_dotenv()

PLANNER_PROMPT = """
You are a cybersecurity analyst tasked with investigating digital indicators using external tools and data sources.

OBJECTIVE:
{input}

INITIAL PLAN:
{plan}

INVESTIGATION LOG:
{past_steps}

YOUR TASK:
- If the objective has been fully addressed, provide a final summary or conclusion.
- If further steps are needed, return only the steps that remain.
- Ensure that each step includes all necessary information (e.g., IP, domain, source).
- Avoid repeating previously completed steps.
- Be precise and concise, as if updating an analyst runbook.

Think like a methodical investigator. Each step should move the investigation forward.
"""

#OBJECTIVE = "Investigate IP 185.199.110.153 for location and threat reputation."
OBJECTIVE = "Investigate IP 185.199.110.153 for location."

def prompt_llm(prompt):
    """Send a prompt to the LLM and return the response text."""
    OPENAI_MODEL = "gpt-4o-mini"
    llm = ChatOpenAI(model=OPENAI_MODEL, temperature=0.1)
    response = llm.invoke(prompt)
    return response.content.strip()

# --- Initial Planning ---
initial_plan_prompt = f"Come up with a step-by-step plan to achieve the following objective:\n\n{OBJECTIVE}"
plan = prompt_llm(initial_plan_prompt)
print("INITIAL PLAN:\n", plan, "\n")

# Split plan into step lines (ignore headings like "Step 1", "Step 2")

import re
step_lines = re.findall(r"(?:^|\n)[\-\*\d\.]+ (.+)", plan)

for step_text in step_lines:
    current_step = step_text.strip()
    print("Step:", current_step)

# --- Execute Step-by-Step ---
completed_steps = []

for step_text in step_lines:
    current_step = step_text.strip()
    print(f"CURRENT STEP: {current_step}")

    # Simulate or execute tool/LLM here
    # For demo purposes, just ask the LLM to 'perform' the step
    execution_result = prompt_llm(f"Perform the following step and summarize the result:\n{current_step}")
    print(f"RESULT: {execution_result}\n")

    completed_steps.append(f"{current_step}: {execution_result}")

    # Ask LLM to update plan
    plan_update_prompt = PLANNER_PROMPT.format(
        input=OBJECTIVE,
        plan=plan,
        past_steps='\n'.join(completed_steps)
    )
    plan = prompt_llm(plan_update_prompt)

    if "final answer" in plan.lower() or len(plan.strip()) == 0:
        print(f"FINAL OUTPUT:\n{plan}")
        break
"""
Demo code for tool calling with two tools, module 4, 
for the course Generative AI in Cybersecurity at UCN.

Author: Henning Thomsen
"""

from langchain.agents import initialize_agent, AgentType
from langchain_openai import ChatOpenAI
from langchain_groq import ChatGroq
from langchain.agents import initialize_agent, AgentType
from langchain.agents import Tool

import requests
import re

from dotenv import load_dotenv
load_dotenv()

# Set up the LLM
OPENAI_MODEL = "gpt-4o-mini"
llm = ChatOpenAI(model=OPENAI_MODEL, temperature=0.1)

# Define the two tools that the LLM agent has at its disposal
# Tool 1: IP Lookup
def ip_lookup(ip_address: str) -> str:
    try:
        response = requests.get(f"http://ip-api.com/json/{ip_address}")
        data = response.json()
        print(data)
        if data['status'] == 'success':
            return (
                f"IP: {data['query']}\n"
                f"Country: {data['country']}\n"
                f"Region: {data['regionName']}\n"
                f"City: {data['city']}\n"
                f"ISP: {data['isp']}\n"
                f"Org: {data['org']}\n"
                f"AS: {data['as']}"
            )
        else:
            return f"IP lookup failed: {data.get('message', 'Unknown error')}"
    except Exception as e:
        return f"Error during IP lookup: {str(e)}"

# Tool 2: Hash Type Identifier
def identify_hash_type(hash_value: str) -> str:
    hash_patterns = {
        "MD5": r"^[a-f0-9]{32}$",
        "SHA1": r"^[a-f0-9]{40}$",
        "SHA256": r"^[a-f0-9]{64}$",
        "SHA512": r"^[a-f0-9]{128}$"
    }
    for hash_type, pattern in hash_patterns.items():
        if re.match(pattern, hash_value.lower()):
            return f"The hash appears to be a {hash_type} hash."
    return "Unknown or unsupported hash type."

# Register tools
tools = [
    Tool(
        name="IPLookup",
        func=ip_lookup,
        description="Use this tool to get geolocation and ISP information about an IP address. Input should be a valid IP like 8.8.8.8."
    ),
    Tool(
        name="HashIdentifier",
        func=identify_hash_type,
        description="Use this tool to identify the type of a given hash string. Input should be a hash like 5d41402abc4b2a76b9719d911017c592."
    )
]

# Initialize the agent
agent = initialize_agent(
    tools=tools,
    llm=llm,
    agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION,
    verbose=True
)

# Example runs
agent.invoke("Where is the IP address 8.8.8.8 located?")

agent.invoke("What type of hash is this: 5d41402abc4b2a76b9719d911017c592?")
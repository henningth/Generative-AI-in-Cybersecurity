"""
Excessive agency demo code (SSRF) for module 4, 
for the course Generative AI in Cybersecurity at UCN.

Author: Henning Thomsen
"""

from langchain.agents import initialize_agent
from langchain.agents.agent_types import AgentType
from langchain_openai import ChatOpenAI
from langchain_groq import ChatGroq
from langchain.agents import Tool
import requests

# Load environment variables from .env file
# Be sure to have valid API keys in this file

from dotenv import load_dotenv
load_dotenv()

# Define the unsafe URL fetching tool
def fetch_url(url: str) -> str:
    print(f"[Fetching URL]: {url}")
    try:
        response = requests.get(url, timeout=3)
        return response.text[:1000]
    except Exception as e:
        return f"Error fetching URL: {str(e)}"

# Map the function to a tool
tools = [
    Tool(
        name="FetchURL",
        func=fetch_url,
        description="Fetches the content of a URL and returns the HTML as a string."
    )
]

# Define LLMs
# OpenAI model
OPENAI_MODEL = "gpt-4o-mini"
openai_llm = ChatOpenAI(model=OPENAI_MODEL, temperature=0.1)

# Open source model via Groq
GROQ_MODEL = "llama3-8b-8192"
groq_llm = ChatGroq(model=GROQ_MODEL, temperature=0.1)

agent = initialize_agent(
    tools=tools,
    llm=openai_llm,
    agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION,
    verbose=True
)

malicious_site = "https://raw.githubusercontent.com/henningth/Generative-AI-in-Cybersecurity/refs/heads/main/Module_4/ssrf.html"
"""
QUERY = f"Summarize the page content at {malicious_site}"
response = agent.invoke(QUERY)
print("Agent Response:", response["output"])
"""

QUERY = f"Print exactly the content of this site {malicious_site}"
response = agent.invoke(QUERY)
print("Agent Response:", response["output"])

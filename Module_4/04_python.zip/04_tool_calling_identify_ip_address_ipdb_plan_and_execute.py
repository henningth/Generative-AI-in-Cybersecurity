"""
Starter code for exercise 5, module 4, 
for the course Generative AI in Cybersecurity at UCN.

Author: Henning Thomsen
"""

from langchain.agents import initialize_agent, AgentType
from langchain_openai import ChatOpenAI
from langchain_groq import ChatGroq
from langchain.agents import initialize_agent, AgentType
from langchain.agents import Tool
from langchain_experimental.plan_and_execute import PlanAndExecute, load_agent_executor, load_chat_planner

import requests
import os

from dotenv import load_dotenv
load_dotenv()

# Set up the LLM
OPENAI_MODEL = "gpt-4o-mini"
llm = ChatOpenAI(model=OPENAI_MODEL, temperature=0.1)

# Define the two tools that the LLM agent has at its disposal
# Tool 1: IP Lookup
def ip_lookup(ip_address: str) -> str:
    try:
        response = requests.get(f"http://ip-api.com/json/{ip_address}")
        data = response.json()
        print(data)
        if data['status'] == 'success':
            return (
                f"IP: {data['query']}\n"
                f"Country: {data['country']}\n"
                f"Region: {data['regionName']}\n"
                f"City: {data['city']}\n"
                f"ISP: {data['isp']}\n"
                f"Org: {data['org']}\n"
                f"AS: {data['as']}"
            )
        else:
            return f"IP lookup failed: {data.get('message', 'Unknown error')}"
    except Exception as e:
        return f"Error during IP lookup: {str(e)}"
    
# Tool 2: Real Threat Intelligence using AbuseIPDB
def check_ip_reputation(ip: str) -> str:
    url = f"https://api.abuseipdb.com/api/v2/check"
    headers = {
        "Key": os.getenv("ABUSEIPDB_API_KEY"),
        "Accept": "application/json"
    }
    params = {"ipAddress": ip}
    
    try:
        response = requests.get(url, headers=headers, params=params)
        data = response.json()
        if data['data']['abuseConfidenceScore'] > 0:
            return (f"{ip} is flagged as malicious. "
                    f"Abuse Confidence Score: {data['data']['abuseConfidenceScore']}%. "
                    f"Reported incidents: {data['data']['totalReports']}.")
        else:
            return f"{ip} is not flagged in AbuseIPDB's database."
    except Exception as e:
        return f"Error during threat check: {str(e)}"
    
# Register tools
tools = [
    Tool(
        name="IPLookup",
        func=ip_lookup,
        description="Use this tool to get geolocation and ownership details of an IP address. Input should be an IP address in a string format, not JSON"
    ),
    Tool(
        name="ThreatIntel",
        func=check_ip_reputation,
        description="Use this tool to check if an IP address has been flagged for malicious activity using AbuseIPDB. Input should be an IP address in a string format, not JSON."
    )
]

# Define planner
planner = load_chat_planner(llm)

# Setup executor
executor = load_agent_executor(llm=llm, tools=tools, verbose=True)


# Initialize agent
agent = PlanAndExecute(planner=planner, executor=executor)

# Example chained run
#agent.invoke("Create a threat analysis report for IP 66.240.205.34 with metadata and abuse status")

plan = planner.plan({"input": "Investigate IP 185.199.110.153 for location and threat reputation."})
print("Plan steps:", plan.steps)

print("Generated Plan:")
for i, step in enumerate(plan.steps, 1):
    print(f"Step {i}: {step.value}")

previous_steps = []
for step in plan.steps:
    print("\n---------------------------------------------------------------\n")
    print(f"Running step: {step.value}")
    step_input = {
        "current_step": step,
        "previous_steps": previous_steps
    }
    result = executor.step(step_input)
    print("Result:", result.response)
    previous_steps.append(result)

print("\nSummary of all steps:")
for i, step_result in enumerate(previous_steps, 1):
    print(f"Step {i}: {step_result.response}")
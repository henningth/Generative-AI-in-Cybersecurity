"""
Demo code for tool calling with two tools (IP lookup and threat intel), module 4, 
for the course Generative AI in Cybersecurity at UCN.

Author: Henning Thomsen
"""

from langchain.agents import initialize_agent, AgentType
from langchain_openai import ChatOpenAI
from langchain_groq import ChatGroq
from langchain.agents import initialize_agent, AgentType
from langchain.agents import Tool

import requests

from dotenv import load_dotenv
load_dotenv()

# Set up the LLM
OPENAI_MODEL = "gpt-4o-mini"
llm = ChatOpenAI(model=OPENAI_MODEL, temperature=0.1)

# Define the two tools that the LLM agent has at its disposal
# Tool 1: IP Lookup
def ip_lookup(ip_address: str) -> str:
    try:
        response = requests.get(f"http://ip-api.com/json/{ip_address}")
        data = response.json()
        print(data)
        if data['status'] == 'success':
            return (
                f"IP: {data['query']}\n"
                f"Country: {data['country']}\n"
                f"Region: {data['regionName']}\n"
                f"City: {data['city']}\n"
                f"ISP: {data['isp']}\n"
                f"Org: {data['org']}\n"
                f"AS: {data['as']}"
            )
        else:
            return f"IP lookup failed: {data.get('message', 'Unknown error')}"
    except Exception as e:
        return f"Error during IP lookup: {str(e)}"
    
# Tool 2: Threat Intelligence (simulated reputation DB)
def check_ip_reputation(ip_info: str) -> str:
    # In a real-world scenario, this would extract the IP and query a reputation API
    if "66.240.205.34" in ip_info:
        return f"{ip_info}\nThis IP is flagged in threat feeds as malicious (GitHub Pages CDN abuse)."
    else:
        return f"{ip_info}\nThis IP is not found in known threat databases."
    
# Register tools
tools = [
    Tool(
        name="IPLookup",
        func=ip_lookup,
        description="Use this tool to get geolocation and ownership details of an IP address. Input should be an IP like 8.8.8.8."
    ),
    Tool(
        name="ThreatIntel",
        func=check_ip_reputation,
        description="Use this tool to check IP metadata (e.g., from IPLookup) against known threat feeds. Input should be IP metadata text."
    )
]

# Initialize agent
agent = initialize_agent(
    tools=tools,
    llm=llm,
    agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION,
    verbose=True
)

# Example chained run
agent.run("Check if the IP address 66.240.205.34 is suspicious.")
from flask import Flask, request, render_template, redirect
import os
from dotenv import load_dotenv
from langchain.chat_models import ChatOpenAI
from langchain_groq import ChatGroq

load_dotenv()

app = Flask(__name__)
COMMENTS = []

# Initialize LLM
OPENAI_MODEL = "gpt-4o-mini" # try also "gpt-3.5-turbo" and others
GROQ_MODEL = "llama3-8b-8192"

llm = ChatOpenAI(model=OPENAI_MODEL, temperature=0)
#llm = ChatGroq(model=GROQ_MODEL, temperature=0)

@app.route("/")
def index():
    return '''
    <h1>Submit a Comment</h1>
    <form action="/post" method="post">
        Username: <input name="user"><br>
        Comment: <textarea name="comment"></textarea><br>
        <button type="submit">Submit</button>
    </form>
    <p>Then view comments: <a href="/comments?user=alice">View Alice's Comments</a></p>
    '''

@app.route("/post", methods=["POST"])
def post_comment():
    user = request.form["user"]
    comment = request.form["comment"]
    COMMENTS.append({"user": user, "comment": comment})
    return redirect("/")

@app.route("/comments")
def comments():
    user = request.args.get("user", "alice")
    user_comments = [c["comment"] for c in COMMENTS if c["user"].lower() == user.lower()]
    
    if not user_comments:
        return "No comments found."

    prompt = f"Summarize the following comments by user '{user}':\n" + "\n".join(user_comments)
    
    try:
        #response = llm([HumanMessage(content=prompt)])
        response = llm.invoke(prompt)
        summary = response.content
    except Exception as e:
        summary = f"[Error]: {str(e)}"

    return render_template("comments.html", summary=summary)

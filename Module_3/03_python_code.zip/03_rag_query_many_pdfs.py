"""
Python file for Retrieval Augmented Generation, for the course Generative AI in Cybersecurity at UCN.

Querying a vector database that contains many PDF files.

Author: Henning Thomsen
"""

from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import Chroma
from langchain_core.output_parsers.string import StrOutputParser
from langchain_core.prompts import PromptTemplate
from langchain_core.runnables import RunnablePassthrough
from langchain_openai import ChatOpenAI

# Load environment variables from .env file
# Be sure to have valid API keys in this file

from dotenv import load_dotenv
load_dotenv()

# Load the vector database from disk
vectorstore = Chroma(
    collection_name="nist_collection",
    embedding_function=OpenAIEmbeddings(),
    persist_directory="./chroma_pdf_db",  # Change this to load another database
)

# Our prompt template, note that it has two variables (why does it need that?)
template = """Answer the question based only on the following context: {context}
Question: {question}"""

# Create prompt template object
prompt = PromptTemplate.from_template(template)

# Use OpenAI as our LLM, be sure to experiment with Open source models via Groq
llm = ChatOpenAI(model="gpt-4o-mini", temperature=0.1)

# LangChain expects a retriever object, not a plain vectorstore
retriever = vectorstore.as_retriever()

# Our RAG application, note that we use LangChain Expression Language (LCEL)
chain = (
{"context": retriever, "question": RunnablePassthrough()}
| prompt
| llm
| StrOutputParser()
)

# Here we ask the RAG a question. This queries the vectorstore, and returns
# relevant information as the context.
result = chain.invoke("Tell me about OT System Design Considerations!")

# Output the result, note that we don't need to write result.content (why?)
print(result)
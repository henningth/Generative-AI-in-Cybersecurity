"""
Python script for invoking SQL queries using an ReAct agent, 
for the course Generative AI in Cybersecurity at UCN.

This file uses the students.db file created using the 03_create_students_db.py script.

Author: Henning Thomsen
"""

from dotenv import load_dotenv
load_dotenv()

from sqlalchemy import create_engine
from langchain_community.utilities.sql_database import SQLDatabase

# Connect to the existing students.db file
engine = create_engine("sqlite:///students.db")
db = SQLDatabase(engine=engine)

from langchain_openai import ChatOpenAI
from langchain_community.agent_toolkits.sql.toolkit import SQLDatabaseToolkit
from langchain_community.agent_toolkits.sql.base import create_sql_agent
from langchain.agents.agent_types import AgentType

# Use a reliable model for tool use
llm = ChatOpenAI(model="gpt-3.5-turbo", temperature=0)

toolkit = SQLDatabaseToolkit(db=db, llm=llm)

agent_executor = create_sql_agent(
    llm=llm,
    toolkit=toolkit,
    agent_type=AgentType.ZERO_SHOT_REACT_DESCRIPTION,
    verbose=True,
    handle_parsing_errors=True
)

response = agent_executor.invoke("List the names of students who are studying Cybersecurity.")
print("Agent Response:", response["output"])
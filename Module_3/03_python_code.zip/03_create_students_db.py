"""
Python script for creating a simple SQLite database for LangChain Agent exercises, 
for the course Generative AI in Cybersecurity at UCN.

Author: Henning Thomsen
"""

import sqlite3

def create_students_db(db_path="students.db"):
    # Connect to (or create) the database file
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # Create a simple table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            age INTEGER,
            major TEXT
        )
    """)

    # Insert sample data
    students = [
        ("Alice", 22, "Cybersecurity"),
        ("Bob", 20, "Computer Science"),
        ("Charlie", 23, "Data Science")
    ]

    cursor.executemany("INSERT INTO students (name, age, major) VALUES (?, ?, ?)", students)

    # Commit changes and close the connection
    conn.commit()
    conn.close()
    print(f"Database created and saved to '{db_path}'.")

# Run the function
create_students_db()

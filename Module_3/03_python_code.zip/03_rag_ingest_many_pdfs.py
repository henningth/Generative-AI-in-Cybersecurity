"""
Python file for Retrieval Augmented Generation, for the course Generative AI in Cybersecurity at UCN.

Ingest several PDFs into vector DB

Author: Henning Thomsen
"""

from langchain_community.document_loaders import DirectoryLoader, PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import Chroma

# Load environment variables from .env file
# Be sure to have valid API keys in this file

from dotenv import load_dotenv
load_dotenv()

# Load all PDF files from a directory
pdf_loader = DirectoryLoader("./pdf_files", loader_cls=PyPDFLoader)
pdf_docs = pdf_loader.load()

# Split documents into chunks
text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
split_docs = text_splitter.split_documents(pdf_docs)

# Create Chroma Vector Database
vectorstore = Chroma.from_documents(documents=split_docs,
                                    collection_name="nist_collection", 
                                    embedding=OpenAIEmbeddings(),
                                    persist_directory="./chroma_pdf_db")
"""
Python script for adding numbers using an ReAct agent, 
for the course Generative AI in Cybersecurity at UCN.

Author: Henning Thomsen
"""

# Load environment variables from .env file
# Be sure to have valid API keys in this file

from dotenv import load_dotenv
load_dotenv()

from langchain.agents import Tool

def add_numbers(inputs: str) -> str:
    numbers = [float(x) for x in inputs.split() if x.replace('.', '', 1).isdigit()]
    return str(sum(numbers))

add_tool = Tool(
    name="Calculator",
    func=add_numbers,
    description="Use this tool to add numbers. Input should be a space-separated list of numbers."
)

from langchain.agents import initialize_agent
from langchain.agents.agent_types import AgentType
from langchain_openai import ChatOpenAI

llm = ChatOpenAI(model="gpt-4o-mini", temperature=0.1)

agent = initialize_agent(
    tools=[add_tool],
    llm=llm,
    agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION,
    verbose=True
)

response = agent.invoke("What is 5.2 plus 3.8?")
print("Agent Response:", response["output"])
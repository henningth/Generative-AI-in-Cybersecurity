"""
Python script for exercise 8 in module 3, for the course Generative AI in Cybersecurity at UCN.

Author: Henning Thomsen
"""

from langchain_openai import ChatOpenAI
from langchain_groq import ChatGroq
from dotenv import load_dotenv

# Load environment variables from .env file
# Be sure to have valid API keys in this file
load_dotenv()

# This prompt is from the article: https://arxiv.org/pdf/2410.05229
prompt = """
Oliver picks 44 kiwis on Friday. Then he picks 58 kiwis on Saturday. On Sunday, he picks double the
number of kiwis he did on Friday, but five of them were a bit smaller than average. How many kiwis
does Oliver have?
"""

# Run OpenAI model
print("OpenAI model: \n")
llm = ChatOpenAI(model="gpt-3.5-turbo", temperature=0, verbose=True)
response = llm.invoke(prompt)
print(response.content)

# Run model via Groq
print("Groq model: \n")
llm = ChatGroq(model="llama3-8b-8192", temperature=0)
response = llm.invoke(prompt)
print(response.content)